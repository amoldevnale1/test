const a = 3;
console.log(a);