import React from 'react';
import ReactDOM from 'react-dom';
import { cleanup, render } from '@testing-library/react';
import { RecoilRoot } from 'recoil';
import AddLocation from './AddLocation';

afterEach(cleanup);

jest.mock('react-i18next', () => ({
  useTranslation: () => {
    return {
      t: (str) => str,
      i18n: {
        changeLanguage: () => new Promise(() => { }),
      },
    };
  },
}));

jest.mock('react-router-dom', () => ({
  useParams: () => {
    return {
      locationId: []
    };
  },
  useHistory: () => {
    return {
      push: jest.fn()
    };
  },
  useLocation: () => {
    return {
      urlLocation: jest.fn()
    };
  }
}));

jest.mock('../../../hooks/useUser',() => ({
  useUser: () => {
    return {
      userPermissions: [],
      userRole: {}
    };
  }
}));

describe('render Location Grid Component',() => {
  it('renders without crashing',() => {
    const div = document.createElement('div');
    ReactDOM.render(<RecoilRoot><LocationGrid {...props}/></RecoilRoot>, div);
  });

  test('Location Grid has Text',() => {
    const { getByText } = render(
      <RecoilRoot>
        <LocationGrid {...props} />
      </RecoilRoot>
    );
    expect(getByText('location.locationGrid.columns.locationName')).toBeInTheDocument();
  });
});