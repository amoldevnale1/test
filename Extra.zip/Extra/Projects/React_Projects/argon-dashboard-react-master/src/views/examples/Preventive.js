import React, { useState } from "react";
import {Link} from "react-router-dom";
// reactstrap components
import {
  Badge,
  Card,
  CardHeader,
  CardFooter,
  DropdownMenu,
  DropdownItem,
  UncontrolledDropdown,
  DropdownToggle,
  Media,
  Pagination,
  PaginationItem,
  PaginationLink,
  Progress,
  Table,
  Container,
  Row,
  UncontrolledTooltip,
  Button,
  Modal, ModalHeader, ModalBody, ModalFooter, FormGroup,
  InputGroupAddon,
  InputGroupText,
  InputGroup,
  Col,
  Input
} from "reactstrap";

// core components
import Header from "components/Headers/Header.js";

import ReactDatetime from "react-datetime";

//import Preventive from "views/examples/Preventivecreate.js";

// function SupervisorFormDetails() {
//   function handleClick() {
//     alert(11);
//   }
//   return ( <Button className="my-4" color="primary" type="button" onClick={handleClick}>
//   +
// </Button>);
// }

function SupervisorFormDetails() {
  //const history = useHistory();
  function addCorrectiveFrom() {
    //history.push("/admin/tables");
  }
  return ( <Button className="my-4" color="primary" type="button" onClick={addCorrectiveFrom}>
  Sign in
</Button>);
}

const Preventive = () => {
  return (
    <>
      <Header />
      {/* Page content */}
      
      <Container className="mt--7" fluid>
        {/* Table */}
        
        <Row>
          <div className="col">
            <Card className="shadow">
                <CardHeader className="border-0">
                    <Row className="align-items-center">
                        <div className="col">
                            <h3 className="mb-0">Preventive Maintance</h3>
                        </div>
                        <div className="col text-right">
                            <Link to="/admin/preventivecreate" className="btn btn-primary">Create Preventive Maintenance</Link>
                        </div>
                    </Row>
                    <br/>
                    <Row>
                        <Col md="4">
                            <InputGroup className="input-group-alternative">
                                <InputGroupAddon addonType="prepend">
                                    <InputGroupText>
                                    <i className="ni ni-single-02" />
                                    </InputGroupText>
                                </InputGroupAddon>
                                <Input type="select" name="select">
                                    <option>Operator Name</option>
                                    <option value="Amol_Devnale">Amol Devnale</option>
                                    <option value="Vicky_Kanojiya">Vicky Kanojiya</option>
                                    <option value="Ajay_Rahane">Ajay Rahane</option>
                                    <option value="Sagar_Jadhav">Sagar Jadhav</option>
                                </Input>
                            </InputGroup>
                        </Col>
                        <Col md="4">
                            <FormGroup>
                                <InputGroup className="input-group-alternative">
                                    <InputGroupAddon addonType="prepend">
                                    <InputGroupText>
                                        <i className="ni ni-calendar-grid-58" />
                                    </InputGroupText>
                                    </InputGroupAddon>
                                    <ReactDatetime
                                    inputProps={{
                                        placeholder: "Select Start Date"
                                    }}
                                    timeFormat={false}
                                    />
                                </InputGroup>
                            </FormGroup>
                        </Col>
                        <Col md="4">
                            <FormGroup>
                                <InputGroup className="input-group-alternative">
                                    <InputGroupAddon addonType="prepend">
                                    <InputGroupText>
                                        <i className="ni ni-calendar-grid-58" />
                                    </InputGroupText>
                                    </InputGroupAddon>
                                    <ReactDatetime
                                    inputProps={{
                                        placeholder: "Select End Date"
                                    }}
                                    timeFormat={false}
                                    />
                                </InputGroup>
                            </FormGroup>
                        </Col>
                    </Row>
                </CardHeader>
              
              <Table className="align-items-center table-flush" responsive>
                <thead className="thead-light">
                  <tr>
                    <th scope="col">WO. No.</th>
                    <th scope="col">WO. Title</th>
                    <th scope="col">Operator Name</th>
                    <th scope="col">Opening Date</th>
                    {/* <th scope="col">Short Description</th> */}
                    <th scope="col">Status</th>
                    <th scope="col">Priority</th>
                    {/* <th scope="col">Tower</th> */}
                    <th scope="col">Closing Date</th>
                    <th>Action</th>
                    
                    {/*<th scope="col" />*/}
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td>123</td>
                    <td>Check temperature</td>
                    <td>Mahesh Doke</td>
                    <td>10-03-2021</td>
                    {/* <td>This is description</td> */}
                    <td>Open</td>
                    <td>High</td>
                    {/* <td>S-7</td> */}
                    <td>15-04-2021</td>
                    <td>
                      <i className="fas fa-edit text-success mr-3" style={{cursor:"pointer"}}/>
                      <i className="fas fa-eye text-rgr mr-3" style={{cursor:"pointer"}}/>
                    </td>
                  </tr>

                  <tr>
                    <td>456</td>
                    <td>Check water</td>
                    <td>Vishal Shrma</td>
                    <td>15-03-2021</td>
                    {/* <td>This is short description</td> */}
                    <td>In Progress</td>
                    <td>Medium</td>
                    {/* <td>A-7</td> */}
                    <td>17-03-2021</td>
                    <td>
                      <i className="fas fa-edit text-success mr-3" style={{cursor:"pointer"}}/>
                      <i className="fas fa-eye text-rgr mr-3" style={{cursor:"pointer"}}/>
                    </td>
                  </tr>

                  <tr>
                    <td>789</td>
                    <td>Check Fan</td>
                    <td>Anil Rathod</td>
                    <td>17-02-2021</td>
                    {/* <td>This is test message</td> */}
                    <td>Closed</td>
                    <td>Low</td>
                    {/* <td>P-7</td> */}
                    <td>19-02-2021</td>
                    <td>
                      <i className="fas fa-edit text-success mr-3" style={{cursor:"pointer"}}/>
                      <i className="fas fa-eye text-rgr mr-3" style={{cursor:"pointer"}}/>
                    </td>
                  </tr>

                  <tr>
                    <td>147</td>
                    <td>Check machine</td>
                    <td>Pratik Roy</td>
                    <td>19-03-2021</td>
                    {/* <td>This is description</td> */}
                    <td>Open</td>
                    <td>High</td>
                    {/* <td>S-7</td> */}
                    <td>20-03-2021</td>
                    <td>
                      <i className="fas fa-edit text-success mr-3" style={{cursor:"pointer"}}/>
                      <i className="fas fa-eye text-rgr mr-3" style={{cursor:"pointer"}}/>
                    </td>
                  </tr>
                </tbody>
              </Table>
              <CardFooter className="py-4">
                <nav aria-label="...">
                  <Pagination
                    className="pagination justify-content-end mb-0"
                    listClassName="justify-content-end mb-0"
                  >
                    <PaginationItem className="disabled">
                      <PaginationLink
                        href="#pablo"
                        onClick={(e) => e.preventDefault()}
                        tabIndex="-1"
                      >
                        <i className="fas fa-angle-left" />
                        <span className="sr-only">Previous</span>
                      </PaginationLink>
                    </PaginationItem>
                    <PaginationItem className="active">
                      <PaginationLink
                        href="#pablo"
                        onClick={(e) => e.preventDefault()}
                      >
                        1
                      </PaginationLink>
                    </PaginationItem>
                    <PaginationItem>
                      <PaginationLink
                        href="#pablo"
                        onClick={(e) => e.preventDefault()}
                      >
                        2 <span className="sr-only">(current)</span>
                      </PaginationLink>
                    </PaginationItem>
                    <PaginationItem>
                      <PaginationLink
                        href="#pablo"
                        onClick={(e) => e.preventDefault()}
                      >
                        3
                      </PaginationLink>
                    </PaginationItem>
                    <PaginationItem>
                      <PaginationLink
                        href="#pablo"
                        onClick={(e) => e.preventDefault()}
                      >
                        <i className="fas fa-angle-right" />
                        <span className="sr-only">Next</span>
                      </PaginationLink>
                    </PaginationItem>
                  </Pagination>
                </nav>
              </CardFooter>
            </Card>
          </div>
        </Row>
        
      </Container>
    </>
  );
};

export default Preventive;
