import React, { useState } from "react";
import {Link} from "react-router-dom";
// reactstrap components
import {
  FormGroup,
  Form,
  Input,
  InputGroupAddon,
  InputGroupText,
  InputGroup,
  Row,
  Col,
  Table,
  Container,
  Button 
} from "reactstrap";

// core components
import Header from "components/Headers/Header.js";

import ReactDatetime from "react-datetime";

// function SupervisorFormDetails() {
//   function handleClick() {
//     alert(11);
//   }
//   return ( <Button className="my-4" color="primary" type="button" onClick={handleClick}>
//   +
// </Button>);
// }



class Supervisor extends React.Component {
  render() {
  return (
    <>
      <Header />
      {/* Page content */}
      <Container className="mt--7" fluid>
      
        {/* Table */}
        <Form>
            <Row>
                <Col md="6">
                    <FormGroup>
                        <h3>Create Corrective Maintance</h3>
                    </FormGroup>
                </Col>
            </Row>
            <Row>
                <Col md="6">
                    <FormGroup>
                            <Input type="select" name="select">
                                <option>Select Equipment Category</option>
                                <option value="Chiller">Chiller</option>
                                <option value="Compressure">Compressure</option>
                                <option value="Graders">Graders</option>
                            </Input>
                    </FormGroup>
                </Col>
                <Col md="6">
                    <FormGroup>
                        <Input type="select" name="select">
                            <option>Select Device</option>
                            <option value="Chiller_1">Chiller 1</option>
                            <option value="Chiller_2">Chiller 2</option>
                            <option value="Chiller_3">Chiller 3</option>
                        </Input>
                    </FormGroup>
                </Col>
            </Row>

            <Row>
                <Col md="6">
                    <FormGroup>
                            <Input type="select" name="select">
                                <option>Select Tasks</option>
                                <option value="compressure_unit">Check compressure unit</option>
                                <option value="water_inlet">Check water inlet & outlet valve</option>
                                <option value="out_lubrication">Check out lubrication</option>
                            </Input>
                    </FormGroup>
                </Col>
                <Col md="6">
                    <FormGroup>
                        <Input type="select" name="select">
                            <option>Select Operator</option>
                            <option value="Operator_1">Operator 1</option>
                            <option value="Operator_2">Operator 2</option>
                            <option value="Operator_3">Operator 3</option>
                        </Input>
                    </FormGroup>
                </Col>
            </Row>

            <Row>
                <Col md="6">
                    <FormGroup>
                        <InputGroup className="input-group-alternative">
                            <InputGroupAddon addonType="prepend">
                            <InputGroupText>
                                <i className="ni ni-calendar-grid-58" />
                            </InputGroupText>
                            </InputGroupAddon>
                            <ReactDatetime
                            inputProps={{
                                placeholder: "Select Start Date"
                            }}
                            timeFormat={false}
                            />
                        </InputGroup>
                    </FormGroup>
                </Col>
                <Col md="6">
                    <FormGroup>
                        <InputGroup className="input-group-alternative">
                            <InputGroupAddon addonType="prepend">
                            <InputGroupText>
                                <i className="ni ni-calendar-grid-58" />
                            </InputGroupText>
                            </InputGroupAddon>
                            <ReactDatetime
                            inputProps={{
                                placeholder: "Select End Date"
                            }}
                            timeFormat={false}
                            />
                        </InputGroup>
                    </FormGroup>
                </Col>
            </Row>

            <Row>
                <Col md="12">
                    <FormGroup>
                    <Input
                        placeholder="Remark"
                        rows="3"
                        type="textarea"
                    />
                    </FormGroup>
                </Col>
            </Row>

            <Row>
                <Col md="6">
                    <FormGroup>
                        <div className="input-group">
                            <div className="input-group-prepend">
                                <span className="input-group-text" id="inputGroupFileAddon01">
                                Upload Documents
                                </span>
                            </div>
                            <div className="custom-file">
                                <input
                                type="file"
                                className="custom-file-input"
                                id="inputGroupFile01"
                                aria-describedby="inputGroupFileAddon01"
                                style={{cursor:"pointer"}}
                                />
                                <label className="custom-file-label" htmlFor="inputGroupFile01">
                                Choose file
                                </label>
                            </div>
                        </div>
                    </FormGroup>
                </Col>
            </Row>

            <br />

            <Row style={{textAlign:"center"}}>
                <Col md="12">
                    <FormGroup>
                        <Button color="info" type="button">Cancel</Button>
                        <Button color="success" type="button">Assign Activity</Button>
                    </FormGroup>
                </Col>
            </Row>

        </Form>
      </Container>
    </>
  );
}
}

export default Supervisor;
