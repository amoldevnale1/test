import React from 'react';
import './App.css';
import Home from './containers/Home';
import Header from './components/Header';
import Hero from './components/Hero';
import {BrowserRouter as Router, Switch, Route} from 'react-router-dom'
import ContactUS from './containers/ContactUs';
import Post from './containers/Post';

function App() {
    return (
        <Router>
            <div className="App">
                <Header />
                <Hero />
                <Route exact path="/">
                    <Home />
                </Route>
                <Route path="/about-us">
                    <Home />
                </Route>
                <Route path="/contact-us">
                    <ContactUS />
                </Route>
                <Route path="/post/:id" component={Post} />
                
            </div>
        </Router>
    );
}

export default App;
