import React from 'react'
import './style.css'

export default function Logo() {
    return (
        <div className="logo">
            <a href="#">Amol</a>
        </div>
    )
}
