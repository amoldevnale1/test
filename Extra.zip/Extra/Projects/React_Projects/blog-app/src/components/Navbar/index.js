import React, {useState} from 'react'
import './style.css'
import {NavLink} from 'react-router-dom'

export default function Navbar(props) {
    const[search, setSearch] = useState(false);

    const submitSearch = (e) => {
        e.preventDefault();
        alert("aa")
    }

    const openSearch = () => {
        setSearch(true);
    }

    const searchClass = search ? "searchinput active" : "searchinput";

    return (
        <div className="navbar">
            <ul className="navbarMenu">
                <li><NavLink to="/">Home</NavLink></li>
                <li><NavLink to="/about-us">About Us</NavLink></li>
                <li><NavLink to="/contact-us">Contact Us</NavLink></li>
                <li><NavLink to="/post">Post</NavLink></li>
               
            </ul>
            <div className="search">
                <form onSubmit={submitSearch}>
                    <input type="text" className={searchClass} placeholder="Search" />
                    <img onClick={openSearch} className="searchicon" src={require("../../assets/icons/search.png")} alt="Search" />
                </form>
            </div>
        </div>
    )
}
