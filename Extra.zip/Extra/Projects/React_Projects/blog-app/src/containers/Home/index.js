import React from 'react'
import './style.css'
import Sidebar from '../../components/Sidebar';
import Card from '../../components/UI/Card';
import RecentPosts from './RecentPosts';

const SideImage = props => {
   return (
        <div style={{height: `${props.height}px`}}>
            <img src={props.src} alt=""/>
        </div>
   )     
}

const Home = props => {
    const galleryHeight = 450;
    const galleryStyle = {
        height: galleryHeight+'px',
        overfloe: 'hidden'
    }
    const sideImageHeight = galleryHeight / 3;
    
    return (
        <div>
            <Card>
                <div className="galleryPost" style={galleryStyle}>
                    <section style={{width: '70%'}}>
                        <div>
                            <img src={"https://1.bp.blogspot.com/-q2G-P44QbXs/V9_PE1fnC-I/AAAAAAAAD5A/5zt-KGj_SpUZSQwI6DA5ldLYQfC3LvG8wCLcB/s1600/5.jpg"} alt=""/>
                        </div>
                    </section>
                    <section className="sideImageWrapper" style={{width: '30%'}}>
                        <SideImage height={sideImageHeight}
                            src={'https://3.bp.blogspot.com/-zlQO0zfYQd8/V9_M2m9Px-I/AAAAAAAAD4o/qucehvSfM-4210-UQCaFPr6hs7NvJdLHQCPcB/w680/2-1.jpg'} 
                        />
                        <SideImage height={sideImageHeight}
                            src={'https://3.bp.blogspot.com/-zlQO0zfYQd8/V9_M2m9Px-I/AAAAAAAAD4o/qucehvSfM-4210-UQCaFPr6hs7NvJdLHQCPcB/w680/2-1.jpg'} 
                        />
                        <SideImage height={sideImageHeight}
                            src={'https://3.bp.blogspot.com/-zlQO0zfYQd8/V9_M2m9Px-I/AAAAAAAAD4o/qucehvSfM-4210-UQCaFPr6hs7NvJdLHQCPcB/w680/2-1.jpg'} 
                        />
                    </section>
                </div>
            </Card>

            <section className="HomeContainer">
                <RecentPosts style={{width: '70%'}} />
                <Sidebar />
            </section>
        </div>
    );
}

export default Home;