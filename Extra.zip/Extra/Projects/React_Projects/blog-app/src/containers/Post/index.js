import React from 'react'
import './style.css'
import BlogPosts from '../../components/BlogPosts'
import Sidebar from '../../components/Sidebar'

 const Post = (props) => {
    console.log(props)
    return (
        <section className="container">
            <BlogPosts {...props} />
            <Sidebar />
        </section>
    )
}

export default Post;
