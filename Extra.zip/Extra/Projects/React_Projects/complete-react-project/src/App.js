import "./App.css";
import { ToastContainer, toast } from "react-toastify";

function App() {
  const buttonClick = () => toast("Wow so easy!");

  return (
    <div className="App">
      <ToastContainer />
      <h1>Please click on button</h1>
      <button onClick={buttonClick}>Click</button>
    </div>
  );
}

export default App;
