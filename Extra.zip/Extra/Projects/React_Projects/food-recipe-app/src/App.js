import React, {useState, useEffect} from 'react';
import './App.css';
import Header from './components/Header';
import Recipe from './components/Recipe';
import Axios from "axios";

function App() {
    const [search, setSearch] = useState("chiken");
    const onInputChange = (e) => {
        setSearch(e.target.value)
    }

    const [recipe, setRecipe] = useState([]);
    const APP_ID = "e99eb0a3";
    const APP_KEY = "05014865ba46a5b9cca82fdd7a1fe984";
    useEffect( () => {
        getRecipes();
    }, []);
    const getRecipes = async () => {
        const res = await Axios.get(`https://api.edamam.com/search?q=${search}&app_id=${APP_ID}&app_key=${APP_KEY}`);
        //console.log(res);
        setRecipe(res.data.hits);
    }

    const onSearchClick = () => {
        getRecipes();
    }

    return (
        <div className="App">
            <Header 
                search={search} 
                onInputChange={onInputChange}
                onSearchClick={onSearchClick}    
            />
            <div className="container">
                <Recipe recipe={recipe} />
            </div>
        </div>
    );
}

export default App;
