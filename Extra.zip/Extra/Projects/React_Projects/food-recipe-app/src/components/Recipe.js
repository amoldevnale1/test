import React from "react";
import RecipeItem from "./RecipeItem";

const Recipe = (props) => {
    const {recipe} = props;
    return(
        <div className="card-columns" style={{margin: '2%'}}>
            {
                recipe.map(recipe => (
                    <RecipeItem 
                                key={Math.random() * 100}
                                name={recipe.recipe.label}
                                image={recipe.recipe.image}
                    />
                ))
            }
        </div>
    )
}

export default Recipe;