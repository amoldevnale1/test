import React, {useState} from 'react';
import './App.css';

const App = () => {
  const [val, setVal] = useState('')
  const [inputText, setInputText] = useState([])

  const inputVal = (e) => {
    setVal(e.target.value);
  }

  const add = () => {
    setInputText((oldVal) => {
      console.log(oldVal)
      return [...oldVal, val]
    });
    setVal('');
  }
  return(
    <>
      <div className='main_div'>
        <div className='center_div'>
          <br />
          <h1>ToDo List</h1>
          <br />  
          <input type='text' placeholder='Add a Items' value={val} onChange={inputVal} />
          <button onClick={add}>+</button>
          <ol>
              {
                inputText.map( (list) => {
                  return <li>{list}</li>
                })
              }
          </ol>
        </div>
      </div>
    </>
  );
}

export default App;