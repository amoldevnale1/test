########### To start the project ###################

step1. clone the repository using "git clone https://github.com/sachin7478/new_react_practise.git" using terminal or cmd

step2. on terminal locate the folder in which "package.json" file exists OR in root folder

step3. hit command "npm install"

step4. hit "npm start"

#####################################################
