import React from 'react'
import './App.css'
import ParentComp from './ParentComp'

function App() {
  return (
    <div className='App'>
      Form <br/>
      <ParentComp />
    </div>
  )
}

export default App