import React, { useState } from 'react'

export default function ParentComp() {
  const [inputs, setInputs] = useState({
    name: "",
    email: ""
  });
  const [tableData, setTableData] = useState([]);
  const [editClick, setEditClick] = useState(false);
  const [editIndex, setEditIndex] = useState("");

  const handleChnage = (e) => {
    setInputs({
      ...inputs,
      [e.target.name] : e.target.value,
    })
  }

  const handleSubmit = (e) => {
    e.preventDefault();
    if(editClick) {
      const tempTableData = tableData;
      Object.assign(tempTableData[editIndex], inputs);
      setTableData([...tempTableData]);
      setEditClick(false);
      setInputs({
        name: "",
        email: ""
      });
    }
    else {
      setTableData([...tableData, inputs])
      setInputs({
        name: "",
        email: ""
      });
    }
  }

  const handleDelete = (index) => {
    const filterData = tableData.filter((item,i) => i !== index);
    setTableData(filterData);
  }

  const handleEdit = (index) => {
    const tempData = tableData[index];
    setInputs({name: tempData.name, email: tempData.email});
    setEditClick(true);
    setEditIndex(index);
  }

  return(
    <div>
      <form onSubmit={handleSubmit}>
        <label>Name</label>
        <input type="text" name="name" value={inputs.name} onChange={handleChnage} /><br />

        <label>Email</label>
        <input type="text" name="email" value={inputs.email} onChange={handleChnage} /><br />

        <button type='submit'>{editClick ? "Update" : "Add"}</button>
      </form>
      <table style={{textAlign:'center'}}>
        <thead>
          <tr>
            <th>Name</th>
            <th>Email</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          { tableData.map((item,i) => (
              <tr key={i}>
                <td>{item.name}</td>
                <td>{item.email}</td>
                <td>
                  <button onClick={() => handleEdit(i)}>Edit</button>
                  <button onClick={() => handleDelete(i)}>Delete</button>
                </td>
              </tr>
            )) 
          }
        </tbody>
      </table>
    </div>
  )
}
