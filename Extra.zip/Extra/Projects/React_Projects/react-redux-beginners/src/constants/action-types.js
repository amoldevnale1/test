export const INCREMENT = "INCREMENT";
export const DECREMENT = "DECREMENT";
export const RESET = "RESET";

export const ADD_USER = "ADD_USER";
export const REMOVE_USER = "REMOVE_USER";