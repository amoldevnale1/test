import React from 'react';
import iPhone from '../images/iphonexdesign.webp'
import cart from '../images/cart.png'

function Home(props) {
    //console.log("home comp",props)
    console.log("home comp",props)
    return (
        <div>
            <div className='add-to-cart'>
                <img  src={cart} alt='cart' />
            </div>
            <h1>Home Component</h1>
            <div className='cart-wrapper'>
                <div className='img-wrapper item'>
                    <img src={iPhone} alt='i-phone' />
                </div>
                <div className='text-wrapper item'>
                    <span>
                        i-Phone
                    </span>
                    <span>
                        Price: $10,000.00 
                    </span>
                </div>
                <div className='btn-wrapper item'>
                    <button onClick={() => props.addToCartHandler({price: 1000, name:'phone'})}>Add To Cart</button>
                </div>
            </div>
        </div>
    )
}

export default Home;