import React,{useState} from "react";

// Start Toggle Code
function App() {
    const [show, setShow] = useState(true);
    return (
        <div>
            {
                show ? <h1>Hello World</h1> : null
            }
            <button onClick={() => setShow(!show)} > Toggle </button>
        </div>
    )
}
// End Toggle Code
export default App;

