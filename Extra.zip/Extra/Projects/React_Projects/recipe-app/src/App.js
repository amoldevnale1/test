import React, { useState, useEffect } from 'react';
import './App.css';
import Recipe from './Recipe';

const App = () => {
    const APP_ID = "ea38d5eb";
    const APP_KEY = "0cf6783f87225aa31af88efe0aaa1917";

    const [recipes, setRecipes] = useState([]);
    const [search, setSearch] = useState("");
    const [query, setQuery] = useState("mango");

    useEffect(() => {
        getRecipes();
    },[query])

    const getRecipes = async () => {
        const apiRes = await fetch(`https://api.edamam.com/search?q=${query}&app_id=${APP_ID}&app_key=${APP_KEY}`);
        const data = await apiRes.json();
        console.log(data)
        setRecipes(data.hits);
    }

    const updateSearch = e => {
        setSearch(e.target.value);
        //console.log(search)
    }

    const getSearch = e => {
        e.preventDefault();
        setQuery(search);
        //setSearch("");
    }

    return (
        <div className="App">
            <form onSubmit={getSearch} className="search-form">
                <input className="search-bar" type="text" value={search} onChange={updateSearch} />
                <button className="search-button" type="submit">Search</button>
            </form>
            <div className="recipes">
                {recipes.map(recipe => (
                    <Recipe key={recipe.recipe.label} 
                    title={recipe.recipe.label} 
                    calories={recipe.recipe.calories} 
                    image={recipe.recipe.image} 
                    ingredients={recipe.recipe.ingredients}
                    />
                ))}
            </div>
        </div>
    )
}

export default App;
