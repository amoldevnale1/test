import {ADD_TODO, UPDATE_TODO, DELETE_TODO} from './types';

export const addTodo = (message) => ({
    type: ADD_TODO,
    message,
});

export const updateTodo = ({id, message}) => ({
    type: UPDATE_TODO,
    id,
    message,
});

export const deleteTodo = (id) => ({
    type: DELETE_TODO,
    id,
});