import React from 'react';
import './App.css';

import { BrowserRouter as Router, Route, Link } from "react-router-dom"
import {Navbar, Nav} from "react-bootstrap"

import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faPlus, faSearch, faHome, faList, faUser } from '@fortawesome/free-solid-svg-icons'

import Home from "./components/Home"
import List from "./components/List"
import Create from "./components/Create"
import Search from "./components/Search"
import Update from "./components/Update"
import Login from "./components/Login"

function App() {
    return (
        <div className="App">
            <Router>

                <Navbar bg="light" expand="lg">
                    <Navbar.Brand href="#home">Resto</Navbar.Brand>
                    <Navbar.Toggle aria-controls="basic-navbar-nav" />
                    <Navbar.Collapse id="basic-navbar-nav">
                        <Nav className="mr-auto">
                            <Nav.Link href="#home"><Link to="/"><FontAwesomeIcon icon={faHome} /> Home</Link></Nav.Link>
                            <Nav.Link href="#link"><Link to="/list"><FontAwesomeIcon icon={faList} /> List</Link></Nav.Link>
                            <Nav.Link href="#link"><Link to="/create"><FontAwesomeIcon icon={faPlus} /> Create</Link></Nav.Link>
                            <Nav.Link href="#link"><Link to="/search"><FontAwesomeIcon icon={faSearch} /> Search</Link></Nav.Link>
                            <Nav.Link href="#link"><Link to="/login"><FontAwesomeIcon icon={faUser} /> Login</Link></Nav.Link>
                        </Nav>
                    </Navbar.Collapse>
                </Navbar>

                <Route exact path="/">
                    <Home />
                </Route>
                <Route path="/list">
                    <List />
                </Route>
                <Route path="/create">
                    <Create />
                </Route>
                <Route path="/search">
                    <Search />
                </Route>
                <Route path="/update/:id"
                render={props => (
                    <Update {...props}/>
                    )} >
                </Route>
                <Route path="/login"
                render={props => (
                    <Login {...props}/>
                    )} >
                </Route>

            </Router>
        </div>
    );
}

export default App;
