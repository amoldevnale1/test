import React, { Component } from 'react'

export default class Create extends Component {
    constructor()
    {
        super();
        this.state = {
            name: null,
            email: null,
            address: null,
            rating: null
        }
    }
    create()
    {
        fetch("http://localhost:3000/resto", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(this.state)
        })
        .then((response) => response.json()
        .then((result) => { alert("Resto Created") })
        )
    } 

    
    render() {
        return (
            <div>
                <h1>Create</h1>
                <input onChange={(event) => {this.setState({name: event.target.value})} } 
                placeholder="Enter Resto Name" /> <br /> <br />
                <input onChange={(event) => {this.setState({email: event.target.value})} } 
                placeholder="Enter Email Name" /> <br /> <br />
                <input onChange={(event) => {this.setState({address: event.target.value})} } 
                placeholder="Enter Address Name" /> <br /> <br />
                <input onChange={(event) => {this.setState({rating: event.target.value})} } 
                placeholder="Enter Rating Name" /> <br /> <br />
                <button onClick={() => {this.create() }}>Add Resto</button>
            </div>
        )
    }
}
