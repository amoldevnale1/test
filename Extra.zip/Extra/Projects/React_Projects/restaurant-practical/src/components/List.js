import React, { Component } from 'react'
import { Table } from "react-bootstrap"
import { Link } from "react-router-dom"

import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faEdit, faTrash } from '@fortawesome/free-solid-svg-icons'

export default class List extends Component {
    constructor() {
        super();
        this.state = {
            list: null
        }
    }

    getRestoListData()
    {
        fetch("http://localhost:3000/resto").then((response) => {
            response.json().then((result) => {
                this.setState({ list: result })
            })
        })
    }
    componentDidMount() 
    {
        this.getRestoListData();
    }

    delete(id)
    {
        fetch("http://localhost:3000/resto/"+id, {
            method: "DELETE",
        })
        .then((response) => response.json()
        .then((result) => { 
            alert("Resto Deleted")
            this.getRestoListData(); 
        })
        )
    }

    render() {
        return (
            <div>
                <h1>Resto List</h1>
                {
                    this.state.list ?
                        <div>
                            <Table striped bordered hover>
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Name</th>
                                        <th>Email</th>
                                        <th>Address</th>
                                        <th>Rating</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {
                                        this.state.list.map((item) =>
                                            <tr>
                                                <td>{item.id}</td>
                                                <td>{item.name}</td>
                                                <td>{item.email}</td>
                                                <td>{item.address}</td>
                                                <td>{item.rating}</td>
                                                <td>
                                                    <Link to={"/update/"+item.id}><FontAwesomeIcon icon={faEdit} /></Link>
                                                    <Link onClick={() => this.delete(item.id)}><FontAwesomeIcon icon={faTrash} /></Link>
                                                </td>
                                            </tr>
                                        )
                                    }
                                </tbody>
                            </Table>
                        </div>
                        :
                        <p>Please test API...</p>
                }
            </div>
        )
    }
}
