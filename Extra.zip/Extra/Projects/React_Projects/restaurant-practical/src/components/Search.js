import React, { Component } from 'react'

export default class Search extends Component {
    constructor()
    {
        super();
        this.state = {
            searchData: null,
            noDataForSearch: false
        }
    }
    search(searchValue)
    {
        fetch("http://localhost:3000/resto?q="+searchValue)
        .then((response) => {
            response.json()
            .then((result) => {
                if(result.length > 0)
                {
                    this.setState({searchData: result, noDataForSearch: false})
                }
                else
                {
                    this.setState({noDataForSearch: true, searchData: null})
                }
            })
        })
    }
    render() {
        return (
            <div>
                <h1>Search</h1>
                <input type="text" placeholder="Search" onChange={(event) => this.search(event.target.value)} />
                <div>
                    {
                        this.state.searchData ?
                        <div>
                            {
                                this.state.searchData.map((item) =>
                                <div>
                                    {item.name}
                                </div>
                                )
                            }
                        </div>
                        :
                        ""
                    }
                    {
                        this.state.noDataForSearch ?
                        <h4>No result found</h4>
                        :
                        null
                    }
                </div>
            </div>
        )
    }
}
