import React, { Component } from 'react'

export default class Update extends Component {
    constructor()
    {
        super();
        this.state = {
            name: null,
            email: null,
            address: null,
            rating: null,
            id: null
        }
    }
    componentDidMount()
    {
        fetch("http://localhost:3000/resto/"+this.props.match.params.id)
        .then((response) => {
            response.json()
            .then((result) => {
                this.setState({
                    name: result.name,
                    email: result.email,
                    address: result.address,
                    rating: result.rating,
                    id: result.id,
                })
            })
        })
    }
    update()
    {
        fetch("http://localhost:3000/resto/"+this.state.id, {
            method: "PUT",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(this.state)
        })
        .then((response) => response.json()
        .then((result) => { alert("Resto Updated") })
        )
    }
    render() {
        //console.log(this.props.match.params.id)
        return (
            <div>
                <h1>Update</h1>
                <div>
                <h1>Create</h1>
                <input onChange={(event) => {this.setState({name: event.target.value})} } 
                placeholder="Enter Resto Name" value={this.state.name} /> <br /> <br />
                <input onChange={(event) => {this.setState({email: event.target.value})} } 
                placeholder="Enter Email" value={this.state.email} /> <br /> <br />
                <input onChange={(event) => {this.setState({address: event.target.value})} } 
                placeholder="Enter Address" value={this.state.address} /> <br /> <br />
                <input onChange={(event) => {this.setState({rating: event.target.value})} } 
                placeholder="Enter Rating" value={this.state.rating} /> <br /> <br />
                <button onClick={() => {this.update() }}>Update Resto</button>
            </div>
            </div>
        )
    }
}
