import React from 'react';
import './App.css';

import {BrowserRouter as Router, Route} from "react-router-dom";

import Home from "./components/Home";
import RastaurantDetail from "./components/RastaurantDetail";
import RastaurantSearch from "./components/RastaurantSearch";
import RastaurantCreate from "./components/RastaurantCreate";
import RastaurantUpdate from "./components/RastaurantUpdate";
import RastaurantList from "./components/RastaurantList";
import Login from "./components/Login";
import Logout from "./components/Logout"
import ProtectedRoute from "./components/ProtectedRoute"

function App() {
    return (
        <div className="App">
            <Router>

                <Route exact path="/">
                    <Home />
                </Route>

                {/* <ProtectedRoute exact path="/" component={Home} /> */}

                <Route path="/list">
                    <RastaurantList />
                </Route>
                <Route path="/create">
                    <RastaurantCreate />
                </Route>
                <Route path="/search">
                    <RastaurantSearch />
                </Route>
                <Route path="/detail">
                    <RastaurantDetail />
                </Route>
                <Route path="/update/:id"
                    render={props=>(
                        <RastaurantUpdate {...props} /> 
                    )}
                >
                </Route>
                <Route path="/login"
                    render={props=>(
                        <Login {...props} /> 
                    )}
                >
                </Route>
                <Route path="/logout">
                    <Logout />
                </Route>

            </Router>
            
        </div>
    );
}

export default App;
