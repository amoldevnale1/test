import React, { Component } from 'react'
import { Button } from 'react-bootstrap';
import LoginMenu from "./LoginMenu"

export default class componentName extends Component {
    constructor()
    {
        super();
        this.state = {
            username: "",
            password: ""
        }
    }

    login()
    {
        fetch("http://localhost:3001/login?q=" + this.state.username).then((response) => {
            response.json().then((result) => {
                //console.log("result", result)

                if(result.length > 0)
                {
                    localStorage.setItem("loginData", JSON.stringify(result))
                    console.log(this.props.history.push("list"))
                }
                else
                {
                    alert("Invalid Username")
                }
            })
        })
    }

    render() {
        return (
            <div>
                <LoginMenu />
                <input type="text" name="username" 
                placeholder="Enter username"
                onChange={(event) => this.setState({username: event.target.value})} /> <br /><br />

                <input type="password" name="password" 
                placeholder="Enter username"
                onChange={(event) => this.setState({password: event.target.value})} /> <br /><br />

                <Button onClick={()=>this.login()}>Login</Button>

            </div>
        )
    }
}
