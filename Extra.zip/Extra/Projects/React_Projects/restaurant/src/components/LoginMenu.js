import React, { Component } from 'react'

import {Nav, Navbar} from "react-bootstrap"

import {Link} from "react-router-dom";

import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faHome, faPlus, faList, faSearch, faUser } from '@fortawesome/free-solid-svg-icons'

export default class LoginMenu extends Component {
    render() {
        return (
            <div>
                <Navbar bg="light" expand="lg">
                    <Navbar.Brand href="#home">Resto</Navbar.Brand>
                    <Navbar.Toggle aria-controls="basic-navbar-nav" />
                    <Navbar.Collapse id="basic-navbar-nav">
                        <Nav className="mr-auto">
                            {
                                localStorage.getItem("loginData")
                                ?
                                <Nav.Link href="#link"><Link to="/logout"><FontAwesomeIcon icon={faUser} /> Logout</Link></Nav.Link>
                                :
                                <Nav.Link href="#link"><Link to="/login"><FontAwesomeIcon icon={faUser} /> Login</Link></Nav.Link>
                            }
                            
                        </Nav>
                    </Navbar.Collapse>
                </Navbar>
            </div>
        )
    }
}
