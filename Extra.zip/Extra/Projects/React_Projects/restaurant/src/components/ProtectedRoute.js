import React from 'react'
import {Redirect, Route} from "react-router-dom"

const ProtectedRoute = ({component:Cmp, ...restParameter}) => (
    <Route 
        {...restParameter}
        render={(props) => 
            localStorage.getItem.loginData
            ?
            ( <Cmp {...props} />
            )
            :
            <Redirect to="/login"
            />
        }
    />
)

export default ProtectedRoute;
