import React, { Component } from 'react'
import { Button } from 'react-bootstrap'
import Menu from "./Menu"

export default class RastaurantCreate extends Component {
    constructor()
    {
        super();
        this.state = {
            name: null,
            email: null,
            rating: null,
            address: null
        }
    }

    create()
    {
        fetch("http://localhost:3000/restaurant", {
            method: "POST",
            headers: {
                 "Content-Type": "application/json"
            },
            body: JSON.stringify(this.state)
        })
        .then((response) => response.json()
        .then((result) => {alert("Rastaurant has been added successfully.")})
        )
    }

    render() {
        return (
            <div>
                <Menu />
                <h1>Create Rastaurant</h1>
                <div>
                    <input placeholder="Rastaurant Name" 
                        onChange={(event) => this.setState({name: event.target.value})} /> <br/> <br/>
                    <input placeholder="Rastaurant Email" 
                        onChange={(event) => this.setState({email: event.target.value})} /> <br/> <br/>
                    <input placeholder="Rastaurant Rating" 
                        onChange={(event) => this.setState({rating: event.target.value})} /> <br/> <br/>
                    <input placeholder="Rastaurant Address" 
                        onChange={(event) => this.setState({address: event.target.value})} /> <br/> <br/>
                    <Button onClick={() => this.create() }> Create Rastaurant</Button>
                </div>
            </div>
        )
    }
}
