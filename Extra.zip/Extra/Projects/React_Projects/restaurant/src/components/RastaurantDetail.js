import React, { Component } from 'react'
import Menu from "./Menu"

export default class RastaurantDetail extends Component {
    render() {
        return (
            <div>
                <Menu />
                <h1>RastaurantDetail</h1>
            </div>
        )
    }
}
