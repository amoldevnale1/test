import React, { Component } from 'react'

import Menu from "./Menu"

import { Table, Container } from "react-bootstrap";
import { Link } from "react-router-dom";

import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faEdit, faTrash } from '@fortawesome/free-solid-svg-icons'

export default class RastaurantList extends Component {
    constructor() {
        super();
        this.state = {
            list: null
        }
    }

    componentDidMount() {
        this.getData();
    }

    getData()
    {
        fetch("http://localhost:3000/restaurant")
            .then((response) => response.json()
            .then((result) => this.setState({ list: result }))
            )
    }

    delete(id)
    {
        fetch("http://localhost:3000/restaurant/"+id,
        {
            method: "DELETE",
        })
        .then((response) => { response.json()
        .then((result) => { 
            alert("Rastaurant has been deleted successfully.")
            this.getData();
        })
        })
    }

    render() {
        //console.log(this.state)
        return (
            <div>
                <Menu />
                <h1>Rastaurant List</h1>
                <Container>
                {
                    this.state.list
                        ?
                        <div>
                            <Table striped bordered hover>
                                <thead>
                                    <tr>
                                        <th>No.</th>
                                        <th>Name</th>
                                        <th>Email</th>
                                        <th>Rating</th>
                                        <th>Address</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {
                                        this.state.list.map((item, i) =>
                                            <tr>
                                                <td>{item.id}</td>
                                                <td>{item.name}</td>
                                                <td>{item.email}</td>
                                                <td>{item.rating}</td>
                                                <td>{item.address}</td>
                                                <td><Link to={"/update/"+item.id}><FontAwesomeIcon icon={faEdit} color="orange" /></Link>
                                                <span onClick={() => this.delete(item.id)}> <FontAwesomeIcon icon={faTrash} color="red" style={{cursor:"pointer"}} /></span>
                                                </td>
                                            </tr>
                                        )
                                    }
                                </tbody>
                            </Table>
                        </div>
                        :
                        <p>Please test...</p>
                }
                </Container>
            </div>
        )
    }
}
