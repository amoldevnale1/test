import React, { Component } from 'react'
import Menu from "./Menu"

import { Table, Form, Container } from "react-bootstrap";
import { Link } from "react-router-dom";

import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faEdit, faTrash } from '@fortawesome/free-solid-svg-icons'

export default class RastaurantSearch extends Component {
    constructor()
    {
        super();
        this.state = {
            searchData: null,
            noData: false,
            lastSearch: ""
        }
    }
    
    search(searchValue)
    {
        this.setState({lastSearch: searchValue})
        fetch("http://localhost:3000/restaurant?q="+searchValue).then((response) => {
            response.json().then((result) => {
                //console.log(result)
                if(result.length > 0)
                {
                    this.setState({searchData: result, noData: false})
                }
                else
                {
                    this.setState({searchData: null, noData: true})
                }
            })
        })
    }

    delete(id)
    {
        fetch("http://localhost:3000/restaurant/"+id,
        {
            method: "DELETE",
        })
        .then((response) => { response.json()
        .then((result) => { 
            alert("Rastaurant has been deleted successfully.")
            this.search(this.state.lastSearch);
        })
        })
    }

    render() {
        return (
            <div>
                <Menu />
                <h1>Search Rastaurant Name</h1>
                <Container>
                    <Form.Control type="text" placeholder="Search Rastaurant Name..." onChange={(event) => this.search(event.target.value)} />
                    <br />
                    <div>
                        {
                            this.state.searchData
                            ?
                            <div>
                                <Table striped bordered hover>
                                    <thead>
                                        <tr>
                                            <th>No.</th>
                                            <th>Name</th>
                                            <th>Email</th>
                                            <th>Rating</th>
                                            <th>Address</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {
                                            this.state.searchData.map((item) => 
                                            <tr>
                                                    <td>{item.id}</td>
                                                    <td>{item.name}</td>
                                                    <td>{item.email}</td>
                                                    <td>{item.rating}</td>
                                                    <td>{item.address}</td>
                                                    <td><Link to={"/update/"+item.id}><FontAwesomeIcon icon={faEdit} color="orange" /></Link>
                                                    <span onClick={() => this.delete(item.id)}> <FontAwesomeIcon icon={faTrash} color="red" style={{cursor:"pointer"}} /></span>
                                                    </td>
                                            </tr>
                                            )
                                        }
                                    </tbody>
                                </Table>
                            </div>
                            :
                            null
                        }

                        {
                            this.state.noData ? <h5>No Data found</h5> : null
                        }
                        
                    </div>
                </Container>
            </div>
            
        )
    }
}
