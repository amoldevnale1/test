import React, { Component } from 'react'
import { Button } from 'react-bootstrap'
import Menu from "./Menu"

export default class RastaurantUpdate extends Component {
    constructor()
    {
        super();
        this.state = {
            name: null,
            email: null,
            rating: null,
            address: null,
            id: null
        }
    }

    componentDidMount()
    {
        fetch("http://localhost:3000/restaurant/"+this.props.match.params.id)
            .then((response) => { response.json()
            .then((result) => {
            //console.log(result)
                this.setState({
                        name: result.name,
                        email: result.email,
                        rating: result.rating,
                        address: result.address,
                        id: result.id
                    })
                })
            })
    }

    update()
    {
        fetch("http://localhost:3000/restaurant/"+this.state.id, {
            method: "PUT",
            headers: {
                 "Content-Type": "application/json"
            },
            body: JSON.stringify(this.state)
        })
        .then((response) => response.json()
        .then((result) => {alert("Rastaurant has been updated successfully.")})
        )
    }

    render() {
        console.log(this.props.match.params.id)
        return (
            <div>
                <Menu />
                <h1>Update Rastaurant</h1>
                <div>
                    <input placeholder="Rastaurant Name" 
                        onChange={(event) => this.setState({name: event.target.value})} value={this.state.name} /> <br/> <br/>
                    <input placeholder="Rastaurant Email" 
                        onChange={(event) => this.setState({email: event.target.value})} value={this.state.email} /> <br/> <br/>
                    <input placeholder="Rastaurant Rating" 
                        onChange={(event) => this.setState({rating: event.target.value})} value={this.state.rating} /> <br/> <br/>
                    <input placeholder="Rastaurant Address" 
                        onChange={(event) => this.setState({address: event.target.value})} value={this.state.address} /> <br/> <br/>
                    <Button onClick={() => this.update() }> Update Rastaurant</Button>
                </div>
            </div>
        )
    }
}
