import axios from "axios";

const API_KEY = "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";
export const headers = {
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${API_KEY}`
    },
  };

export const fetchData = async (input) => {
  
  const response = await axios.post(
    "https://api.openai.com/v1/completions",
    {
      prompt: `Complete this sentence: "${input}"`,
      model: "text-davinci-003",
      max_tokens: 50,
      n: 1,
      stop: ".",
    },
    headers
  );
  return response.data.choices[0].text;
};

export const getData = async (input) => {
    const response = await axios.get("https://mocki.io/v1/f7e37b60-0a89-4e7f-80a0-4036abbfc17b");
    return response.data;
}

export const postData = async (url, body) => {
    const response = await axios.post("https://mocki.io/v1/f7e37b60-0a89-4e7f-80a0-4036abbfc17b", body);
    return response.data;
}

 
