import React from 'react';
import { BrowserRouter, Routes, Route } from "react-router-dom";
import LoginValidator from "./components/auth/LoginValidator";
import DashBoard from "./components/Dashboard";
import MCQSections from './components/mcqQuestions/MCQSections';
import MCQQuize from './components/mcqQuestions/MCQQuize';
import MCQTimer from './components/mcqQuestions/MCQTimer';
import CodeEditor from "./components/codeEditor/CodeEditor";
import Chatbot from "./components/chatbot/Chatbot";
// import questionBank from './components/mcqQuestions/questionBank.json';

function App() {

  return (
    <div className="App">
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<LoginValidator />} />
          <Route path="/dashboard" element={<DashBoard/>} />
          <Route path="/mcqsection" element={<MCQSections />} />
          <Route path="/mcqquize/:id/:type" element={<MCQQuize />} />
          <Route path="/codeeditor" element={<CodeEditor />} />
          <Route path="/mcqtimer" element={<MCQTimer />} />
          <Route path="/chatbot" element={<Chatbot />} />
        </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;
