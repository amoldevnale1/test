// import Button from "react-bootstrap/Button";
// import Card from "react-bootstrap/Card";

function CardComponent(props) {
    const { title, text, buttonName, buttonAction } = props;
    return (<>
      {/* // <Card style={{ width: "18rem" }}>
      //   <Card.Body>
      //     <Card.Title>{title}</Card.Title>
      //     <Card.Text>{text}</Card.Text>
      //     <Button variant="primary" onClick={buttonAction}>
      //       {buttonName}
      //     </Button>
      //   </Card.Body>
      // </Card> */}
      <div className="card" style={{width: "18rem"}}>
    <div class="card-body">
      <h5 class="card-title">{title}</h5>
      <p class="card-text">{text}</p>
      <a href="#" class="btn btn-danger mt-3">{buttonName}</a>
    </div>
  </div>
  </>
    );
  }
  
  export default CardComponent;
  