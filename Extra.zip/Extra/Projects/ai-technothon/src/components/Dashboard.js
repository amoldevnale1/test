import React from "react";
import { Link } from "react-router-dom";
// import CardComponent from "../Card";
import "./Dashboard.css";
const DashBoard = () => {
  return (
    <>
      <h4 className="items-center d-flex my-4 justify-content-center text-success">Dashboard</h4>
      <br />
      
      <div className="dashboard">
        <div className="row">
          <div className="card">
            <div className="card-body">
              <Link to='/mcqsection'>MCQ Questions</Link>
            </div>
          </div>
        </div><br />
        <div className="row">
          <div className="card">
            <div className="card-body">
              <Link to='/codeeditor'>Coding Challenges</Link>
            </div>
        </div>
      </div><br />
      <div className="row">
          <div className="card">
            <div className="card-body">
              <Link to='/chatbot'>Smart Chatbot</Link>
            </div>
        </div>
      </div>
        <div className="col"></div>
      </div>
    </>
  );
};
export default DashBoard;
