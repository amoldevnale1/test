import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import "./Login.css";

const Login = (props) => {
  const { setFormType } = props;
  const navigate = useNavigate();
  let formData = { emailId: "", password: "" };
  const [loginData, setLoginData] = useState(formData);

  const onChangeData = (e) => {
    let id = e.target.id;
    setLoginData((loginData) => ({
      ...loginData,
      [id]: e.target.value,
    }));
  };

  const handleLoginSubmit = (e) => {
    // e.preventDefault();
    setLoginData(loginData);
    console.log("loginData", loginData);
    navigate(`/dashboard`);
  };

  return (
    <div className="container login-container">
      <div className="row">
        <div className="col-md-3" />
        <div className="col-md-6 login-form-1">
          <h3>Login</h3>
          <form onSubmit={handleLoginSubmit}>
            <div className="form-group">
              <input
                type="email"
                className="form-control"
                placeholder="Your Email *"
                value={loginData.emailId}
                id="emailId"
                required
                onChange={(e) => {
                  onChangeData(e);
                }}
              />
            </div>
            <br />
            <div className="form-group">
              <input
                type="password"
                className="form-control"
                placeholder="Your Password *"
                value={loginData.password}
                id="password"
                required
                onChange={(e) => {
                  onChangeData(e);
                }}
              />
            </div>
            <br />
            <div className="form-group">
              <input type="submit" className="btnSubmit" value="Login" />
            </div>
            <br />
            <div className="form-group linktext">
              Don't have an account?
              <div
                className="link pdl10"
                onClick={() => {
                  setFormType("signup");
                }}
              >
                Signup
              </div>
            </div>
          </form>
        </div>
        <div className="col-md-3" />
      </div>
    </div>
  );
};
export default Login;
