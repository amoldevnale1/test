import React from "react";
import Login from "./Login";
import Signup from "./Signup";

const LoginValidator = () => {
  const [formType, setFormType] = React.useState("login");
  return (
    <>
      {formType === "login" ? (
        <Login setFormType={setFormType} />
      ) : (
        <Signup setFormType={setFormType} />
      )}
    </>
  );
};
export default LoginValidator;
