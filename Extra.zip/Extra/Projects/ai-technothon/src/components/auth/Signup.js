import React, { useState } from "react";
import "./Login.css";

const Signup = (props) => {
  const { setFormType } = props;
  let formData = {
    userType: "",
    username: "",
    email: "",
    password: "",
    yearsofexp: "",
    skillset: "",
  };
  const [signupData, setSignupData] = useState(formData);
  const userTypeList = ["Select User Type *", "Interviwer", "Candidate"];
  const primarySkillList = [
    "Select Primary Skill *",
    "React",
    "JavaScipt",
    "Angular",
  ];
  const yearOfExperience = ["Select Year Of Experience *", "0-3", "3-6", "6-9"];

  const onChangeData = (e) => {
    let id = e.target.id;
    setSignupData((signupData) => ({
      ...signupData,
      [id]: e.target.value,
    }));
  };

  const handleSignupSubmit = (e) => {
    // e.preventDefault();
    setSignupData(signupData);
    console.log("signupData", signupData);
  };

  return (
    <div className="container login-container">
      <div className="row">
        <div className="col-md-3" />
        <div className="col-md-6 login-form-1">
          <h3>Signup</h3>
          <form onSubmit={handleSignupSubmit}>
            <div className="form-group">
              <select 
                required
                className="form-control form-select"
                id="userType"
                onChange={(e) => {
                  onChangeData(e);
                }}
                value={signupData.userType}
              >
                {userTypeList.map((item, index) => {
                  return (
                    <option key={index} value={item}>
                      {item}
                    </option>
                  );
                })}
              </select>
            </div>
            <br />
            <div className="form-group">
              <input
                type="text"
                className="form-control"
                placeholder="Username *"
                minLength={4}
                maxLength={15}
                value={signupData.username}
                id="username"
                required
                onChange={(e) => {
                  onChangeData(e);
                }}
              />
            </div>
            <br />
            <div className="form-group">
              <input
                type="email"
                className="form-control"
                placeholder="Email *"
                value={signupData.email}
                id="email"
                required
                onChange={(e) => {
                  onChangeData(e);
                }}
              />
            </div>
            <br />
            <div className="form-group">
              <input
                type="password"
                className="form-control"
                placeholder="Password *"
                minLength={4}
                maxLength={15}
                value={signupData.password}
                id="password"
                required
                onChange={(e) => {
                  onChangeData(e);
                }}
              />
            </div>
            <br />
            <>
              {signupData.userType === "Candidate" && (
                <>
                  <div className="form-group">
                    <select
                      className="form-control form-select"
                      id="skillset"
                      onChange={(e) => {
                        onChangeData(e);
                      }}
                      value={signupData.skillset}
                    >
                      {primarySkillList.map((item, index) => {
                        return (
                          <option key={index} value={item}>
                            {item}
                          </option>
                        );
                      })}
                    </select>
                  </div>
                  <br />
                  <div className="form-group">
                    <select
                      className="form-control form-select"
                      id="yearsofexp"
                      onChange={(e) => {
                        onChangeData(e);
                      }}
                      value={signupData.yearsofexp}
                    >
                      {yearOfExperience.map((item, index) => {
                        return (
                          <option key={index} value={item}>
                            {item}
                          </option>
                        );
                      })}
                    </select>
                  </div>
                  <br />
                </>
              )}
            </>
            <div className="form-group form-switch"></div>
            <div className="form-group">
              <input type="submit" className="btnSubmit" value="Signup" />
            </div>
            <br />
            <div className="form-group linktext">
              Already have and account?
              <div
                className="link pdl10"
                onClick={() => {
                  setFormType("login");
                }}
              >
                Login
              </div>
            </div>
          </form>
        </div>
        <div className="col-md-3" />
      </div>
    </div>
  );
};
export default Signup;
