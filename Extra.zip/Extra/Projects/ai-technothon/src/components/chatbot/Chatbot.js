import "./Chatbot.css"
// import Logo from "./images/Per1.png";
// import Send from "./images/send.svg";
import React, {useState} from "react";
import {fetchData} from "../../Api";

const Chatbot = () => {
  const [input, setInput] = useState("");
  const [completedSentence, setCompletedSentence] = useState("");
  const [textVal, setTextVal] = useState("");
  const [chatText, setChatText] = useState([]);
  const renderUserMessage = (event) => {
    setTextVal(event.target.value);
    // const userInput = event.key;
    // if (userInput === "Enter") {
    //   let newTextArr = renderMessageEle(textVal, "user", chatText);
    //   setChatText(newTextArr);
    //   setTextVal("");
    //   setTimeout(() => {
    //     renderChatbotResponse(textVal, newTextArr);
    //     setScrollPosition();
    //   }, 1000);
    // } else {
    //   let newTextVal = textVal + userInput;
    //   setTextVal(newTextVal);
    // }
  };
  const onEnterKey = (event) => {
    const userInput = event.key;
    if (userInput === "Enter") {
      let newTextArr = renderMessageEle(textVal, "user", chatText);
      setChatText(newTextArr);
      setTextVal("");
      setTimeout(() => {
        renderChatbotResponse(textVal, newTextArr);
        setScrollPosition();
      }, 1000);
      handleClick();
    }
  };

  const renderChatbotResponse = (userInput, newTextArr) => {
    const res = getChatbotResponse(userInput);
    setChatText(renderMessageEle(res, null, newTextArr));
  };

  const renderMessageEle = (txt, type, list) => {
    let className = "user-message";
    if (type !== "user") {
      className = "chatbot-message";
    }
    let subObj = { name: className, value: txt };
    let newtextArr = [...list];
    newtextArr.push(subObj);
    return newtextArr;
  };

  const getChatbotResponse = (userInput) => {
    return responseObj[userInput] === undefined
      ? "Please try something else"
      : responseObj[userInput];
  };
  const chatBody = document.querySelector(".chat-body");

  const setScrollPosition = () => {
    if (chatBody.scrollHeight > 0) {
      chatBody.scrollTop = chatBody.scrollHeight;
    }
  };
  const responseObj = {
    hello: "Hey ! How are you doing ?",
    hey: "Hey! What's Up",
    today: new Date().toDateString(),
    time: new Date().toLocaleTimeString()
  };
  const [chatOpen, setChatopen] = React.useState(false);

  async function handleClick() {
    try {
      const completedSentence = await fetchData(input);
      setCompletedSentence(completedSentence);
    } catch (error) {
      console.error(error);
    }
  }
  
  return (
    <>
      {chatOpen ? (
        <div className="containerChatBot">
          <div className="chat-header">
            <div className="logo">
              {/* <img src={Logo} alt="cwt" /> */}
            </div>
            <div className="title">Interview</div>
            <div
              className="close"
              onClick={() => {
                setChatopen(false);
                setChatText([]);
              }}
            >
              <i
                className="fa fa-close close"
                style={{ fontSize: "36px !important" }}
              ></i>
            </div>
          </div>
          <div className="chat-body">
            
          {completedSentence && <p>{completedSentence}</p>}
          </div>
          <div className="chat-input">
            <div className="input-sec">
              <input
                type="text"
                id="txtInput"
                placeholder="Type here..."
                autoFocus
                // value={textVal}
                value={input}
                // onChange={renderUserMessage}
                onChange={(event) => setInput(event.target.value)}
                onKeyPress={onEnterKey}
              />
            </div>
            <div className="send">
              {/* <img src={Send} alt="send" /> */}
            </div>
          </div>
        </div>
      ) : (
        <div className="containerBotIcon">
          <img
            className="svgClass"
            // src={Chat}
            alt="SVG"
            onClick={() => {
              setChatopen(true);
            }}
            // onClick={handleClick}
          />
        </div>
      )}
      
    </>
  );
};
export default Chatbot;
