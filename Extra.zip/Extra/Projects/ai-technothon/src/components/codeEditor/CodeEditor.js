import '../codeEditor/CodeEditor.css';
import React,{useState} from 'react';
import InbuiltCodeEditor from './InbuiltCodeEditor';
import Landing from '../Landing';
function CodeEditor(){
    const languages = ['java','javaScript','react','c','python']
    const [dropDown , setDropDown] = useState(false);
    const [listOfLanguages , setListOfLanguages] = useState(languages)
    const [selectedLanguage , setSelectedLanguage] = useState('')
    const selectLanguage = (e) =>{
        // console.log(e.target.innerText)
        setSelectedLanguage(e.target.innerText)
    }
    console.log(selectedLanguage)
    return(
        <>
            <div className="code-ed-container">
                <div className='code-ed-title'>Coding Test</div>
                <div className='code-ed-drp'>
                    {/* <div className='code-ed-drp-dwn' onClick={()=>setDropDown(!dropDown)}>{selectedLanguage ? selectedLanguage : "Select language"}</div>
                   {dropDown && <div className='list-items-dv'>
                        <ul className='ul-list-items'>
                            {listOfLanguages && listOfLanguages.map((lang)=><li className='list-of-lang' onClick={selectLanguage}>{lang}</li>)}
                        </ul>
                    </div>} */}
                </div>
                <br/>
                <br/>
                <div className='code-ed-content'>
                    <div className='code-ed-left-dv'>
                        <p className='p-statement'>Problem Statement</p>
                        <p className='p-stmt-content'>Write a function which takes a list of strings and returns each line prepended by the correct number</p>
                        <p className='p-statement'>Instructions</p>
                        <p className='p-stmt-content'>The numbering starts at 1. The format is n: string. Notice the colon and space in between.</p>
                    </div>
                    <div className='code-ed-right-dv'>
                        <div className='solution-title'>Solution</div>
                        {/* <textarea className='write-code'></textarea> */}
                        {/* <InbuiltCodeEditor selectedLanguage={selectedLanguage}/> */}
                        <Landing/>
                    </div>
                </div>
            </div>
        </>
    )
}
export default CodeEditor;