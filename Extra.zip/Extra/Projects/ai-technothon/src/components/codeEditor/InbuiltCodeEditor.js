import { useState , useEffect } from 'react';
import Editor from "@monaco-editor/react";
import Axios from 'axios';
// import spinner from './spinner.svg';

function InbuiltCodeEditor({selectedLanguage}) {

	// State variable to set users source code
	const [userCode, setUserCode] = useState(``);

	// State variable to set editors default language
	const [userLang, setUserLang] = useState('javascript');

	// State variable to set editors default theme
	const [userTheme, setUserTheme] = useState("vs-dark");

	// State variable to set editors default font size
	const [fontSize, setFontSize] = useState(20);

	// State variable to set users input
	const [userInput, setUserInput] = useState("");

	// State variable to set users output
	const [userOutput, setUserOutput] = useState("");

	// Loading state variable to show spinner
	// while fetching data
	const [loading, setLoading] = useState(false);

    //while change the language
    const [defaultContent , setDefaultContent] = useState("")

	const options = {
		fontSize: fontSize
	}

    useEffect(()=>{
        if(selectedLanguage){
            setUserLang(selectedLanguage)
        }
    },[selectedLanguage]);

    useEffect(()=>{
        if(userLang){
            if(userLang==='javascript'){
                setDefaultContent('console.log("welcome")')
            }else if(userLang==='python'){
                setDefaultContent('print("Hello world")')
            }else if(userLang === 'java'){
                setDefaultContent('class Message{public static void main(String args[]){System.out.println("Hello world")}}')
            }
        }
    },[userLang])

	// Function to call the compile endpoint
	function compile() {
		setLoading(true);
		if (userCode === ``) {
			return
		}

		// Post request to compile endpoint
		Axios.post(`http://localhost:3000/compile`, {
			code: userCode,
			language: userLang,
			input: userInput
		}).then((res) => {
			setUserOutput(res.data.output);
		}).then(() => {
			setLoading(false);
		})
	}

	// Function to clear the output screen
	function clearOutput() {
		setUserOutput("");
	}

	return (
		<div className="App">
			<div className="main">
				<div className="left-container">
					<Editor
						options={options}
						height="calc(100vh - 200px)"
						width="100%"
						theme={userTheme}
						language={userLang}
						defaultLanguage={userLang}
						defaultValue={defaultContent }
						onChange={(value) => { setUserCode(value) }}
					/>
					<button className="run-btn" onClick={() => compile()}>
						Run
					</button>
				</div>
				<div className="right-container">
					<h4 className='input-head'>Input:</h4>
					<div className="input-box">
						<textarea id="code-inp" onChange=
							{(e) => setUserInput(e.target.value)}>
						</textarea>
					</div>
					<h4 className='input-head'>Output:</h4>
					{loading ? (
						<div className="spinner-box">
							{/* <img src={spinner} alt="Loading..." /> */}
						</div>
					) : (
						<div className="output-box">
							<pre>{userOutput}</pre>
							<button onClick={() => { clearOutput() }}
								className="clear-btn">
								Clear
							</button>
						</div>
					)}
				</div>
			</div>
		</div>
	);
}

export default InbuiltCodeEditor;
