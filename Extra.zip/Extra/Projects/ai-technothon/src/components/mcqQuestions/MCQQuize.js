import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import "./MCQQuize.css";
import axios from "axios";
import MCQTimer from "./MCQTimer";
import { getData } from "../../Api";
import { useNavigate } from "react-router-dom";


export default function MCQQuize() {
  // const [userDetails , setUserId] = useState(JSON.parse(localStorage.getItem('userValues')))
  // console.log(userDetails.userEmail);
  const [questionsData, setQuestionsData] = useState();
  
  const [testType, setTestType] = useState([]);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [selectedOption, setSelectedOption] = useState({selected: {}});
  const id = parseInt(useParams().id);
  const testType1 = useParams().type;
  const time = new Date();
  time.setSeconds(time.getSeconds() + 600); // 10 minutes timer
  const navigate = useNavigate();

  const apiUrl = "https://mocki.io/v1/f7e37b60-0a89-4e7f-80a0-4036abbfc17b";

  useEffect(() => {
    updateData();
    setTestType(testType1);
  }, []);

  function updateData() {
    axios.get(apiUrl).then((res) => {
      setQuestionsData(res.data);
    });
  }
  const handleOptionChange = (option, id) => {
    setSelectedOption(currentState => ({selected: {...currentState.selected, [id]: option}}));
  };

  const handleNextQuestion = () => {
    setCurrentQuestionIndex((prevIndex) => prevIndex + 1);
  };

  const handlePrevQuestion = () => {
    setCurrentQuestionIndex((prevIndex) => prevIndex - 1);
  };

  const changeQuestion = (index) => {
    setCurrentQuestionIndex(index);
  };

  const handleSubmitTest = () => {
    const keys = Object.keys(selectedOption.selected);
    const values = Object.values(selectedOption.selected);
    let selectedAnswers = {userId: null, testType: testType, answers: []};
    for (let i = 0; i < keys.length; i++) {
      selectedAnswers.answers.push({questionId: keys[i], selectedOption: values[i]})
    }
    console.log('selectedAnswers', selectedAnswers);
    getData().then((res) => {
    });
    navigate('/mcqsection');
    

  };

  return (
    <div>
      <h4 className="items-center d-flex my-4 justify-content-center text-success">
        {testType} Quiz
      </h4>
      <div className="container">
        <nav>
          <ul className="pagination pagination-lg">
            {questionsData?.questions?.map((questionBlock, index) => (
              <li
                onClick={() => changeQuestion(index)}
                key={index}
                className={
                  "page-item" +
                  (index === currentQuestionIndex ? " active" : "")
                }
                aria-current="page"
              >
                <span className="page-link">{index + 1}</span>
              </li>
            ))}
          </ul>
        </nav>
        <div className="row">
          <div className="card">
            <div className="card-body">
              <div className="row">
                <div className="col-md-6">
                  <h5 className="card-title card-titles">Time Left : <MCQTimer expiryTimestamp={time} /></h5>
                </div>
                <div className="col-md-6">
                  <div className="row">
                     
                      <div className="col-md-4 card-titles">
                        Unattempted : {questionsData?.numberOfQuestions - (Object.keys(selectedOption?.selected).length)}
                      </div>
                      
                      <div className="col-md-4 card-titles">
                        Attempted  : {Object.keys(selectedOption?.selected).length}
                      </div>
                      <div className="col-md-4">
                        <button type="button" onClick={handleSubmitTest} className="btn btn-danger">Submit Test</button>
                      </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {questionsData?.questions.length > 0 && (
        <div className="d-flex justify-content-center flex-column px-5 py-3">
          <p data-testid="question">
            {questionsData?.questions[currentQuestionIndex].question}
          </p>
          {questionsData?.questions[currentQuestionIndex].options.map((option, index) => (
            <div className="p-2" key={index}>
              <input
                type="radio"
                id={option}
                name={option}
                value={option}
                checked={(selectedOption?.selected[questionsData?.questions[currentQuestionIndex].questionId]) == option}
                onChange={() => handleOptionChange(option, questionsData?.questions[currentQuestionIndex].questionId)}
                data-testid="option-1"
              />
              <label className="px-2" htmlFor="option1">
                {option}
              </label>
            </div>
          ))}

          <div className="items-center d-flex my-4 justify-content-center">
            {currentQuestionIndex > 0 && (
              <button
                className="btn btn-secondary mt-4 prev-btn"
                onClick={handlePrevQuestion}
                data-testid="prev"
              >
                Previous
              </button>
            )}
            {currentQuestionIndex < questionsData.questions.length - 1 && (
              <button
                className="btn btn-primary mt-4"
                onClick={handleNextQuestion}
                data-testid="next"
              >
                Next
              </button>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
