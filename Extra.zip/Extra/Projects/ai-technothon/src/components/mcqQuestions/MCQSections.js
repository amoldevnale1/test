import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import "./MCQSections.css";
export default function MCQSections() {
  const navigate = useNavigate();
  const [questionnaires, setQuestionnaires] = useState([]);
  const [selectedBlock, setSelectedBlock] = useState(null);

  const apiUrl = "json/questionBank.json";

  useEffect(() => {
    updateQuestionBank(true);
  }, []);

  function updateQuestionBank() {
    fetch(apiUrl)
      .then((res) => {
        return res.json();
      })
      .then((data) => {
        setQuestionnaires(data);
      });
  }

  const updateSelectedBlock = (testId, testType) => {
    navigate(`/mcqquize/${testId}/${testType}`);
  };

  return (
    <>
      <h4 className="items-center d-flex my-4 justify-content-center text-success">
        MCQ Questions
      </h4>

      <div className="container">
        <div className="row">
          {questionnaires.map((questionBlock, index) => (
            <QuestionBockcard
              key={index}
              questionBlock={questionBlock}
              updateSelectedBlock={updateSelectedBlock}
            />
          ))}
        </div>
        <br />
        <div className="row">
          <div className="card" style={{ padding: "inherit" }}>
            <h5 className="card-header">Details</h5>
            <div className="card-body">
              <h5 className="card-title">Rules</h5>
              <p>1. There are no reattempts.</p>
              <p className="card-text">
                2. Try sitting in an isolated room with no disturbance of Human
                or Technical in nature.
              </p>
              <p>3. No Bio Breaks will be allowed.</p>
              <p>
                4. Mobile Phones should be switched off and kept away / out of
                reach.
              </p>
              <br />
              <h5 className="card-title">Important Note</h5>
              <p>1. My answers to questions will be my own work</p>
              <p>
                2. I will not copy/memorize the test content, questions/answers
                from anyone else & pass them on to future test-takers
              </p>
              <p>
                3. I will not make my solutions to assignments, quizzes or exams
                available to anyone else
              </p>
              <p>4. I attest that all the answers in the test will be my own</p>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

const QuestionBockcard = (props) => {
  const { id, testType, numberOfQuestions, time, testScore } = props.questionBlock;
  const { updateSelectedBlock } = props;

  const attemptQuiz = (e) => {
    e.preventDefault();
    updateSelectedBlock(id, testType);
  };

  return (
    <>
      <div className="col-4">
        <div className="card mx-3" style={{height: '100%'}}>
          <div className="card-body">
            <h5 className="card-title d-flex justify-content-center">
              {testType}
            </h5>
            <br />
            <h6 className="card-subtitle mb-2 text-muted pb-3">
              Questions : {numberOfQuestions}
            </h6>
            <h6 className="card-subtitle mb-2 text-muted pb-3">
              Time : {time} Minutes
            </h6>
            {testScore != null ?
              (<h6 className="card-subtitle mb-2 text-muted pb-3">
                Your Score : {testScore}/{numberOfQuestions} 
              </h6>): <h6 className="card-subtitle mb-2 text-muted pb-3">Attempt left : 1</h6>
            }
            {/* <p className="card-text">My answers to questions will be my own work.</p>
          <p className="card-text">No Bio Breaks will be allowed.</p>
          <p className="card-text">There are no reattempts.</p> */}
            <button
              className="btn btn-danger mt-3"
              id={testType}
              disabled={testScore != null}
              onClick={attemptQuiz}
            >
              Start Test
            </button>
          </div>
        </div>
      </div>
    </>
  );
};
