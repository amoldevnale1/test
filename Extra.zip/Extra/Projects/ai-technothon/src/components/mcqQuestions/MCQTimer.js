import React, { useEffect } from 'react';
import { useTimer } from 'react-timer-hook';

export default function MCQTimer({ expiryTimestamp }) {
  const {
    seconds,
    minutes,
  } = useTimer({ expiryTimestamp, onExpire: () => console.warn('onExpire called') });
  useEffect(() => {
      if(minutes == 0 && seconds == 59) {
      alert('Only one minute is left.')
    }
  })

  return (
    <>
      <span>{minutes}</span>:<span>{seconds}</span>
    </>
  );
}